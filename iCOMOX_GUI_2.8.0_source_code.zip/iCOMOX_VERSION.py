VSVersionInfo(
  ffi=FixedFileInfo(
    filevers=(0, 2, 8, 0),
    prodvers=(0, 2, 8, 0),
    mask=0x3f,
    flags=0x0,
    OS=0x40004,
    fileType=0x1,
    subtype=0x0,
    date=(0, 0)
    ),
  kids=[
    StringFileInfo(
      [
      StringTable(
        u'040904B0',
        [StringStruct(u'CompanyName', u'Shiratech Solutions'),
        StringStruct(u'FileDescription', u'iCOMOX Monitor DA Kit'),
        StringStruct(u'FileVersion', u'0.2.8.0'),
        StringStruct(u'InternalName', u'iCOMOX_Monitor_2_8_0'),
        StringStruct(u'LegalCopyright', u'\xa9 Copyright(C)2020 Shiratech'),
        StringStruct(u'OriginalFilename', u'iCOMOX_Monitor_2_8_0.exe'),
        StringStruct(u'ProductName', u'iCOMOX Monitor 2.8.0'),
        StringStruct(u'ProductVersion', u'0.2.8.0')])
      ]), 
    VarFileInfo([VarStruct(u'Translation', [1033, 1200])])
  ]
)